# Proyecto Spring Boot - Spring Security: Aseguramiento de EndPoints

## Descripcion

Este proyecto implementa seguridad con **Spring Boot 3.3.4 y Spring Security** para proteger diferentes endpoints de una aplicacion web.

La autenticacion utiliza usuarios almacenados en una base de datos H2 en memoria. Las contrasenas se almacenan utilizando **BCrypt**, y Spring Security controla el acceso de acuerdo con el estado de autenticacion y el rol del usuario.

## Tecnologias

- Java 17
- Spring Boot 3.3.4
- Spring Security
- Spring Data JPA
- Thymeleaf
- H2 Database
- Maven

## Estructura principal

```text
src/main/java/com/example/demo/
├── config/
│   ├── DataLoader.java
│   └── SecurityConfig.java
├── controller/
│   ├── EndpointController.java
│   ├── HomeController.java
│   ├── DashboardController.java
│   └── LoginController.java
├── model/
│   └── Usuario.java
├── repository/
│   └── UsuarioRepository.java
├── service/
│   └── CustomUserDetailsService.java
└── DemoApplication.java
```

## Usuarios de prueba

Los usuarios se crean automaticamente al iniciar la aplicacion:

| Usuario | Contraseña | Rol |
|---|---|---|
| estudiante | clave123 | USER |
| admin | admin123 | ADMIN |

Las contrasenas se almacenan mediante `BCryptPasswordEncoder`.

## Endpoints asegurados

| Endpoint | Acceso |
|---|---|
| `GET /` | Publico |
| `GET /login` | Publico |
| `GET /api/publico` | Publico |
| `GET /api/privado` | Cualquier usuario autenticado |
| `GET /api/usuario` | Solo rol USER |
| `GET /api/admin` | Solo rol ADMIN |
| `GET /dashboard` | Usuario autenticado |
| `POST /logout` | Usuario autenticado |

La regla general es:

```java
.anyRequest().authenticated()
```

Esto significa que cualquier endpoint que no haya sido declarado como publico o que no tenga una regla de rol requiere autenticacion.

## Como ejecutar

### Desde IntelliJ IDEA, Eclipse o Spring Tool Suite

1. Abrir el proyecto como proyecto Maven.
2. Esperar a que Maven descargue las dependencias.
3. Ejecutar `DemoApplication.java`.
4. Abrir:

`http://localhost:8080/login`

### Desde terminal

```bash
mvn spring-boot:run
```

## Pruebas de seguridad

### 1. Endpoint publico

Abrir:

`http://localhost:8080/api/publico`

Debe responder sin iniciar sesion:

```json
{
  "endpoint": "/api/publico",
  "acceso": "publico",
  "mensaje": "Este endpoint no requiere autenticacion."
}
```

### 2. Endpoint privado

Abrir:

`http://localhost:8080/api/privado`

Sin autenticacion, Spring Security solicita iniciar sesion.

Despues de iniciar sesion, el endpoint permite el acceso.

### 3. Endpoint para USER

Iniciar sesion con:

- Usuario: `estudiante`
- Contraseña: `clave123`

Luego abrir:

`http://localhost:8080/api/usuario`

El acceso es permitido porque el usuario tiene el rol `USER`.

### 4. Endpoint para ADMIN

Iniciar sesion con:

- Usuario: `admin`
- Contraseña: `admin123`

Luego abrir:

`http://localhost:8080/api/admin`

El acceso es permitido porque el usuario tiene el rol `ADMIN`.

### 5. Restriccion por rol

Si el usuario `estudiante` intenta acceder a:

`http://localhost:8080/api/admin`

Spring Security no permite el acceso porque el usuario no posee el rol `ADMIN`.

## Configuracion de seguridad

La clase `SecurityConfig` establece las reglas principales:

```java
.requestMatchers("/", "/login", "/css/**", "/api/publico").permitAll()
.requestMatchers("/api/admin").hasRole("ADMIN")
.requestMatchers("/api/usuario").hasRole("USER")
.anyRequest().authenticated()
```

Estas reglas permiten demostrar tres niveles de seguridad:

1. **Publico:** no requiere autenticacion.
2. **Autenticado:** requiere iniciar sesion.
3. **Por rol:** requiere un rol especifico.

## Autenticacion

`CustomUserDetailsService` implementa `UserDetailsService` y busca el usuario por su nombre en la base de datos H2.

Spring Security utiliza la informacion obtenida para validar las credenciales y establecer la autenticacion.

## Control de sesiones

La aplicacion limita cada usuario a una sesion simultanea:

```java
.maximumSessions(1)
```

Tambien se establece un tiempo de expiracion de sesion de 15 minutos mediante:

```properties
server.servlet.session.timeout=15m
```

## Proteccion CSRF

El proyecto mantiene habilitada la proteccion CSRF de Spring Security. Por esta razon, los formularios POST de inicio y cierre de sesion incluyen el token CSRF.

## Conclusion

El proyecto demuestra el aseguramiento de endpoints mediante Spring Security, aplicando autenticacion, autorizacion por roles, proteccion CSRF, control de sesiones y almacenamiento seguro de contrasenas mediante BCrypt.

### Referencia consultada

GeeksforGeeks. *Spring Boot - Cloud Configuration Server And Config Client*. La pagina proporcionada en el enunciado describe Spring Cloud Config Server y Config Client, Java 17 o posterior, Maven y la arquitectura cliente-servidor para configuracion externa. Esta referencia es distinta del objetivo especifico de aseguramiento de endpoints con Spring Security, por lo que el proyecto se centra en la funcionalidad indicada por el enunciado.

