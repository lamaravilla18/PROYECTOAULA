package com.example.demo.controller;

import java.util.Map;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EndpointController {

    @GetMapping("/api/publico")
    public Map<String, String> publico() {
        return Map.of(
                "endpoint", "/api/publico",
                "acceso", "publico",
                "mensaje", "Este endpoint no requiere autenticacion."
        );
    }

    @GetMapping("/api/privado")
    public Map<String, String> privado(Authentication authentication) {
        return Map.of(
                "endpoint", "/api/privado",
                "acceso", "autenticado",
                "usuario", authentication.getName(),
                "mensaje", "Acceso permitido porque el usuario inicio sesion."
        );
    }

    @GetMapping("/api/usuario")
    public Map<String, String> usuario(Authentication authentication) {
        return Map.of(
                "endpoint", "/api/usuario",
                "rol", "USER",
                "usuario", authentication.getName(),
                "mensaje", "Endpoint disponible para usuarios con rol USER."
        );
    }

    @GetMapping("/api/admin")
    public Map<String, String> admin(Authentication authentication) {
        return Map.of(
                "endpoint", "/api/admin",
                "rol", "ADMIN",
                "usuario", authentication.getName(),
                "mensaje", "Endpoint disponible para usuarios con rol ADMIN."
        );
    }
}
