package com.example.demo.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.demo.model.Usuario;
import com.example.demo.repository.UsuarioRepository;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner cargarDatos(UsuarioRepository repo, PasswordEncoder encoder) {
        return args -> {
            if (repo.findByUsername("estudiante").isEmpty()) {
                Usuario u = new Usuario();
                u.setUsername("estudiante");
                u.setPassword(encoder.encode("clave123"));
                u.setRol("USER");
                repo.save(u);
            }

            if (repo.findByUsername("admin").isEmpty()) {
                Usuario admin = new Usuario();
                admin.setUsername("admin");
                admin.setPassword(encoder.encode("admin123"));
                admin.setRol("ADMIN");
                repo.save(admin);
            }
        };
    }
}
