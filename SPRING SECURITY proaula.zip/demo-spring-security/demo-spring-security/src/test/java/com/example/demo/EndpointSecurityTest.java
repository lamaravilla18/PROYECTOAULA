package com.example.demo;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;

@SpringBootTest
@AutoConfigureMockMvc
class EndpointSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void endpointPublicoDebePermitirAcceso() throws Exception {
        mockMvc.perform(get("/api/publico"))
                .andExpect(status().isOk());
    }

    @Test
    void endpointPrivadoDebeRequerirAutenticacion() throws Exception {
        mockMvc.perform(get("/api/privado"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    @WithMockUser(roles = "USER")
    void usuarioPuedeAccederAEndpointUsuario() throws Exception {
        mockMvc.perform(get("/api/usuario"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "USER")
    void usuarioNoPuedeAccederAEndpointAdmin() throws Exception {
        mockMvc.perform(get("/api/admin"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void adminPuedeAccederAEndpointAdmin() throws Exception {
        mockMvc.perform(get("/api/admin"))
                .andExpect(status().isOk());
    }
}
